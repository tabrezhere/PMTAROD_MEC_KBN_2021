﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Net;
using System.Net.Mail;

public partial class Register : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConsistencyCon"].ConnectionString);
    string mailid = "cloudcomputing96@gmail.com";
    string pwd = "clouddata12345";
    string to, subject = "Secret Key", message;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Random rm = new Random();
        int rno = rm.Next(111111, 999999);
        try
        {

            con.Open();
            SqlCommand cmd = new SqlCommand("insert into UserReg values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "','" + rno + "','" + TextBox7.Text + "','waiting',null,'" + TextBox7.Text + "')", con);
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Write("Registered Successfully and Secret Key Sent to Your registered email");
            Label14.Visible = true;      
            Session["MobileUserName"] = TextBox1.Text;
            Session["MobileUseLocation"] = TextBox7.Text;
            Session["MobileUseremail"] = TextBox4.Text;
            Response.Redirect("MobileUserSelectServer.aspx");
            clear();
        }
        catch
        {
            Response.Write("Invalid Data try again. !");
            Label17.Visible = true;
        }


    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        clear();
    }
    public void clear()
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";
        TextBox6.Text = "";
        TextBox7.Text = "";
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminLogin.aspx");
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        Response.Redirect("UserLogin.aspx");
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        Response.Redirect("TPALogin.aspx");
    }
    protected void Button7_Click(object sender, EventArgs e)
    {
        Response.Redirect("OwnerLogin.aspx");
    }
}
