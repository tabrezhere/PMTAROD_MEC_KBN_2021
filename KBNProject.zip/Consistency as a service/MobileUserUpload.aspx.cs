﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminHome : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConsistencyCon"].ConnectionString);
    string f, ml, ty, kk, nww, st, p1, mon, fullpath;
    protected void Page_Load(object sender, EventArgs e)
    {
        string MobileUserName = Session["MobileUserName"].ToString();
        string MobileUserEmail = Session["MobileUseremail"].ToString();
        SqlCommand com = new SqlCommand("GetMobileUserDetails", con);
        com.CommandType = CommandType.StoredProcedure;
        SqlParameter p1 = new SqlParameter("username", MobileUserName);
        com.Parameters.Add(p1);
        con.Open();
        SqlDataReader rd = com.ExecuteReader();
        var dataTable = new DataTable();
        dataTable.Load(rd);
        int UserMobileId = Convert.ToInt32(dataTable.Rows[0][0]);
        string UserMobileName = dataTable.Rows[0][1].ToString();
        string UserMringobileEmail = dataTable.Rows[0][2].ToString();
        Label13.Text = "Welcome to Mobile User " + UserMobileName + " Home Page";
        Label14.Text = "(" + MobileUserEmail + ")";
        autoid();
    }

    private void autoid()
    {
        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("select max(Fid) from ofileup ", con);
        object result = cmd.ExecuteScalar();
        int ID;
        if (result.GetType() != typeof(DBNull))
        {
            ID = Convert.ToInt32(result);
        }
        else
        {
            ID = 0;
        }
        ID = ID + 1;
        Label4.Text = ID.ToString();

        con.Close();
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        FileUpload1.SaveAs(Server.MapPath("~/upload/") + FileUpload1.FileName);
        f = Path.GetFileNameWithoutExtension(FileUpload1.FileName);
        st = Path.GetFileName(FileUpload1.FileName);
        ml = Server.MapPath("~/upload/");
        nww = FileUpload1.FileName;
        ty = Path.GetExtension(FileUpload1.FileName);
        kk = ml + f + ty;

        FileInfo fz = new FileInfo(kk);
        long s1 = fz.Length;
        string fsize = s1.ToString();

        string dat = DateTime.Now.ToString();
        FileStream fs = new FileStream(kk, FileMode.Open, FileAccess.ReadWrite);
        byte[] buffer = new byte[fs.Length];
        fs.Read(buffer, 0, (int)fs.Length);
        fs.Close();
        con.Open();
        SqlCommand cmd1 = new SqlCommand("insert into ofileup (Fid,filename,files,ftype,fsize,filepath,oname,status,date) values(@Fid,@filename,@files,@ftype,@fsize,@filepath,@oname,@status,@date)", con);
        cmd1.Parameters.AddWithValue("@Fid", Label4.Text);
        cmd1.Parameters.AddWithValue("@filename", st);
        cmd1.Parameters.AddWithValue("@files", buffer);
        cmd1.Parameters.AddWithValue("@ftype", ty);
        cmd1.Parameters.AddWithValue("@fsize", fsize);
        cmd1.Parameters.AddWithValue("@filepath", kk);
        cmd1.Parameters.AddWithValue("@oname", Label13.Text);
        cmd1.Parameters.AddWithValue("@status", "Uploaded");
        cmd1.Parameters.AddWithValue("@date", dat);

        cmd1.ExecuteNonQuery();
        con.Close();
        uploadlbl.Text = "File Uploaded Successfully...";
        uploadlbl.Visible = true;
        autoid();
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminUsers.aspx");
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminOwners.aspx");
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminUploads.aspx");
    }
    protected void Button7_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminTPA.aspx");
    }
    protected void Button8_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminLogin.aspx");
    }
}
