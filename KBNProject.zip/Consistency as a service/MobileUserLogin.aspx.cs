﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class TPAPannel : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConsistencyCon"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        //if (e.CommandName == "Select")
        //{
        //    int x = Convert.ToInt32(e.CommandArgument);
        //    GridViewRow row = GridView1.Rows[x];
        //    string fid = row.Cells[0].Text;

        //    con.Open();
        //    SqlCommand com = new SqlCommand("update ofileup set status = 'Accept' where Fid = '"+fid+"'",con);
        //    com.ExecuteNonQuery();
        //    con.Close();
        //    Response.Redirect("TPAPannel.aspx");
        //}
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand com = new SqlCommand("CheckUser", con);
        com.CommandType = CommandType.StoredProcedure;
        SqlParameter p1 = new SqlParameter("username", TextBox1.Text);
        SqlParameter p2 = new SqlParameter("password", TextBox2.Text);
        com.Parameters.Add(p1);
        com.Parameters.Add(p2);
        con.Open();
        SqlDataReader rd = com.ExecuteReader();
       
        if (rd.HasRows)
        {
            Session["MobileUserName"] = TextBox1.Text;
            SqlCommand com1 = new SqlCommand("GetUseremail", con);
            com1.CommandType = CommandType.StoredProcedure;
            SqlParameter p11 = new SqlParameter("username", TextBox1.Text);
            com1.Parameters.Add(p11);
            con.Close();
            con.Open();
            SqlDataReader rd1 = com1.ExecuteReader();
            var dataTable = new DataTable();
            dataTable.Load(rd1);
           
            Session["MobileUseremail"] = dataTable.Rows[0][0].ToString();
            Response.Redirect("MobileUserHomePage.aspx");

        }
        else
        {
            Label14.Text = "Invalid username or password/Pending for Approval.";
            Label14.Visible = true;
        }
        con.Close();

    }


    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("TPAHome.aspx");
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("TPAuploads.aspx");
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        Response.Redirect("TPAverify.aspx");
    }
    protected void Button6_Click(object sender, EventArgs e)
    {

    }
    protected void Button7_Click(object sender, EventArgs e)
    {
        Response.Redirect("TPALogin.aspx");
    }
}
