﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Net;

public partial class OwnerLogin : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConsistencyCon"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {

        SqlCommand com = new SqlCommand("GetServerLocation", con);
        com.CommandType = CommandType.StoredProcedure;
        if (!IsPostBack)
        {

            con.Open();
            SqlDataReader rd = com.ExecuteReader();
            var dataTable = new DataTable();
            dataTable.Load(rd);
            DropDownList1.DataSource = dataTable;
            DropDownList1.DataBind();
            con.Close();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
       

        string SelectedLocation = DropDownList1.SelectedValue.ToString();
        SqlCommand com = new SqlCommand("ServerUtilizationDetails", con);
        com.CommandType = CommandType.StoredProcedure;
        SqlParameter p1 = new SqlParameter("Location", SelectedLocation);
        com.Parameters.Add(p1);
        con.Open();
        SqlDataReader rd = com.ExecuteReader();
        var dataTable = new DataTable();
        dataTable.Load(rd);
        GridView1.DataSource = dataTable;
        GridView1.DataBind();
        con.Close();


    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {


        string fileName = GridView1.SelectedRow.Cells[0].Text;
        string fileType = GridView1.SelectedRow.Cells[1].Text;
        string filePath = "~//upload//" + fileName;
        WebClient req = new WebClient();
        HttpResponse response = HttpContext.Current.Response;
        response.Clear();
        response.ClearContent();
        response.ClearHeaders();
        response.Buffer = true;
        response.AddHeader("Content-Disposition", "attachment;filename=Filename" + fileType);
        byte[] data = req.DownloadData(Server.MapPath(filePath));
        response.BinaryWrite(data);
        response.End();



    }
}
