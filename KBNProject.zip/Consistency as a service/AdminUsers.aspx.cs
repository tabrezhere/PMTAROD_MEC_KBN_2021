﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminUsers : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConsistencyCon"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminHome.aspx");
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminOwners.aspx");
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminUploads.aspx");
    }
    protected void Button7_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminTPA.aspx");
    }
    protected void Button8_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminLogin.aspx");
    }
  

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

        con.Open();
        string SeletedUserName = GridView1.SelectedRow.Cells[0].Text;
        SqlCommand cmd = new SqlCommand("update UserReg set Status='Approved' where Username='" + SeletedUserName + "'", con);
        cmd.ExecuteNonQuery();
        con.Close();
        GridView1.DataBind();
       
    }  

}
