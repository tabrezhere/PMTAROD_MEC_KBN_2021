﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class OwnerLogin : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConsistencyCon"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        //Session["MobileUserName"] = TextBox1.Text;
        //Session["MobileUseLocation"] = TextBox7.Text;
        //Session["MobileUseremail"] = TextBox4.Text;
        Response.Write("Registered Successfully and Secret Key Sent to Your registered email");
        Label13.Text = "Select the Server Here for " + Session["MobileUserName"].ToString();
        txtloc.Text = Session["MobileUseLocation"].ToString();
        txtloc.ReadOnly = true;
        txtemail.Text = Session["MobileUseremail"].ToString();
        txtemail.ReadOnly = true;

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        int SelectedServer = Convert.ToInt32(DropDownList1.SelectedValue);
        SqlCommand cmd = new SqlCommand("update UserReg set ServerID=" + SelectedServer + " where email='"+ txtemail.Text +"'", con);
        cmd.ExecuteNonQuery();
        con.Close();
        Response.Write("Server Addedd Successfully...");
        Response.Redirect("Register.aspx");
  

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
   
}
