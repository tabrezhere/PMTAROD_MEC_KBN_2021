﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminHome : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConsistencyCon"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        string MobileUserName = Session["MobileUserName"].ToString();
        string MobileUserEmail = Session["MobileUseremail"].ToString();
        SqlCommand com = new SqlCommand("GetMobileUserDetails", con);
        com.CommandType = CommandType.StoredProcedure;
        SqlParameter p1 = new SqlParameter("username", MobileUserName);
        com.Parameters.Add(p1);
        con.Open();
        SqlDataReader rd = com.ExecuteReader();
        var dataTable = new DataTable();
        dataTable.Load(rd);
        int UserMobileId = Convert.ToInt32(dataTable.Rows[0][0]);
        string UserMobileName = dataTable.Rows[0][1].ToString();
        string UserMringobileEmail = dataTable.Rows[0][2].ToString();
        Label13.Text = "Welcome to Mobile User "+ UserMobileName+ " Home Page";
        Label14.Text ="("+ MobileUserEmail+")";
    }
    protected void Button3_Click(object sender, EventArgs e)
    {

    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminUsers.aspx");
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminOwners.aspx");
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminUploads.aspx");
    }
    protected void Button7_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminTPA.aspx");
    }
    protected void Button8_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminLogin.aspx");
    }
}
