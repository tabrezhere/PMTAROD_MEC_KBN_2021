﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminHome : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConsistencyCon"].ConnectionString);
    string f, ml, ty, kk, nww, st, p1, mon, fullpath;
    protected void Page_Load(object sender, EventArgs e)
    {
        string MobileUserName = Session["MobileUserName"].ToString();
         string MobileUseremail = Session["MobileUseremail"].ToString();

         Label13.Text = "Welcome to Mobile User" + MobileUserName + " Home";
         Label14.Text = "(" + MobileUseremail + ")";
        SqlCommand com = new SqlCommand("GetMobileUserfileDetails", con);
        com.CommandType = CommandType.StoredProcedure;
        SqlParameter p1 = new SqlParameter("username", MobileUserName);
        com.Parameters.Add(p1);
        con.Open();
        SqlDataReader rd = com.ExecuteReader();
        var dataTable = new DataTable();
        dataTable.Load(rd);
        GridView1.DataSource = dataTable;
        GridView1.DataBind();
    }

    private void autoid()
    {
        con.Close();
        con.Open();
        SqlCommand cmd = new SqlCommand("select max(Fid) from ofileup ", con);
        object result = cmd.ExecuteScalar();
        int ID;
        if (result.GetType() != typeof(DBNull))
        {
            ID = Convert.ToInt32(result);
        }
        else
        {
            ID = 0;
        }
        ID = ID + 1;
        Label4.Text = ID.ToString();

        con.Close();
    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminUsers.aspx");
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminOwners.aspx");
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminUploads.aspx");
    }
    protected void Button7_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminTPA.aspx");
    }
    protected void Button8_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminLogin.aspx");
    }


    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {


        string fileName = GridView1.SelectedRow.Cells[1].Text;
        string fileType = GridView1.SelectedRow.Cells[2].Text;
        string filePath = "~//upload//" + fileName;
        WebClient req = new WebClient();
        HttpResponse response = HttpContext.Current.Response;
        response.Clear();
        response.ClearContent();
        response.ClearHeaders();
        response.Buffer = true;
        response.AddHeader("Content-Disposition", "attachment;filename=Filename.extension");
        byte[] data = req.DownloadData(Server.MapPath(filePath));
        response.BinaryWrite(data);
        response.End();



    }
}
