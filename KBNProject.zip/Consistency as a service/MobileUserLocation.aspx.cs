﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class OwnerLogin : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConsistencyCon"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        string MobileUserName = Session["MobileUserName"].ToString();

        SqlCommand com = new SqlCommand("GetMobileUserLocation", con);
        com.CommandType = CommandType.StoredProcedure;
        SqlParameter p1 = new SqlParameter("username", MobileUserName);
        com.Parameters.Add(p1);
        con.Open();
        SqlDataReader rd = com.ExecuteReader();
        var dataTable = new DataTable();
        dataTable.Load(rd);
        DropDownList1.DataSource = dataTable;
        DropDownList1.DataBind();
        Label13.Text = "Welcome to Mobile User " + MobileUserName;

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Close();
       
        string MobileUserName = Session["MobileUserName"].ToString();
        SqlCommand com = new SqlCommand("GetMobileUserCurrentLocation", con);
        com.CommandType = CommandType.StoredProcedure;
        SqlParameter p1 = new SqlParameter("username", MobileUserName);
        com.Parameters.Add(p1);
        con.Open();
        SqlDataReader rd = com.ExecuteReader();
        var dataTable = new DataTable();
        dataTable.Load(rd);
        string currentLocation = dataTable.Rows[0][0].ToString();
        string SelectedLocation = DropDownList1.SelectedValue;
        SqlCommand cmd = new SqlCommand("update UserReg set Location='" + SelectedLocation + "',PrevLocation='" + currentLocation + "' where Username ='" + MobileUserName + "'", con);
        cmd.ExecuteNonQuery();
        con.Close();
        Response.Write("Server Addedd Successfully...");
        Response.Redirect("Register.aspx");
  

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
   
}
